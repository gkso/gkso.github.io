#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/3

""" Messages transfered between client and server. """

import struct

from message_pb2 import *


MAX_MESSAGE_LENGTH = 1024 # we are not considering supporting many online users!

class MalformedMessageError(Exception):
    """ Received a malformed message """

class UnknownMessageTypeError(Exception):
    """ Received an unknown type message """

class Message(object):
    """"""

    def __init__(self):
        """Constructor"""
        self.length = 0
        self.lengthBuffer = ''
        self.offset = 0
        self.remaining = 0
        self.completed = False
        self.content = None

    def fill(self, data):
        if self.completed:
            return data

        offset = 0
        if self.length == 0:
            # fill the length field first
            if len(data) >= 4-len(self.lengthBuffer):
                offset += 4-len(self.lengthBuffer)
                self.lengthBuffer += data[:offset]
                self.length = struct.unpack('!I', self.lengthBuffer)[0]
                if self.length > MAX_MESSAGE_LENGTH:
                    raise MalformedMessageError
                self.content = ''
                self.remaining = self.length
            else:
                self.lengthBuffer += data
                return ''

        dataLen = len(data)-offset
        if dataLen >= self.remaining:
            self.content += data[offset:offset+self.remaining]
            data = data[self.remaining+offset:]
            self.remaining = 0
            self.completed = True
        else:
            self.content += data[offset:]
            self.offset += dataLen
            self.remaining -= dataLen
            return ''

        return data


MSG_TYPES = ('UserInfo', 'GameInfo', 'UserLogin', 'UserLoginResponse',
             'GetUserList', 'GetUserListResponse', 'GetGameList',
             'GetGameListResponse', 'Ready', 'StartGame', 'PutChess',
             'PutChessResponse', 'PutChessNotification', 'TerminateGame')

########################################################################
class MessageFactory(object):
    """"""

    @classmethod
    def encode(cls, message):
        msg_type = message.DESCRIPTOR.name
        msg_str = message.SerializeToString()
        return msg_type + ':' + msg_str

    @classmethod
    def decode(cls, str_):
        parts = str_.split(':', 1)
        msg_type = parts[0]
        msg_str = parts[1]
        if msg_type not in MSG_TYPES: raise UnknownMessageTypeError
        message = eval(msg_type+'()')
        message.ParseFromString(msg_str)
        return message

    @classmethod
    def encrypt(cls, str_):
        pass

    @classmethod
    def decrypt(cls, str_):
        pass


if __name__ == "__main__":
    msg_send = GetGameListResponse()
    game = msg_send.game.add()
    game.game_name = 'Hello'
    game.user_name.append('player1')
    game.user_name.append('player2')
    game = msg_send.game.add()
    game.game_name = 'World'
    game.user_name.append('player3')
    game.user_name.append('player4')
    print(msg_send)
    str_ = MessageFactory.encode(msg_send)
    #str_ = msg_send.SerializeToString()
    print(str_)
    #msg_recv = UserInfo()
    msg_recv = MessageFactory.decode(str_)
    #msg_recv.ParseFromString(str_)
    print(msg_recv)
