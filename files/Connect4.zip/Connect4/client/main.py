#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

"""
 Connect Four Game
 A simple connect four game supports both local game and network game.
"""

try:
    import pygame
except ImportError, err:
    print "Couldn't load module. %s" % (err)
    import sys
    sys.exit(2)

pygame.init()

import constants
from log import logger


def main():
    logger.info("Connect 4 game starting...")
    pygame.display.set_mode(constants.WINDOW_SIZE)
    pygame.display.set_caption('Connect 4')
    # load resources
    logger.info("Loading resources...")
    from resource import resources

    from game import StartScreen
    game = StartScreen()
    game.start()


if __name__ == "__main__":
    main()
