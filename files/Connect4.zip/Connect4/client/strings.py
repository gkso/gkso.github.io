#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

""" Messages promted in the game, later may be extended to implement I18N. """


LOCAL_GAME = 'Local Game'
NETWORK_GAME = 'Network Game'
QUIT_GAME = 'Quit'

PVP = 'Player V.S. Player'
PVC = 'Player V.S. Computer'
BACK = 'Back'

CONNECT_TO = 'Connecting to the server...'
WAITING_FOR = 'Waiting for another player to join the game...'
CONNECT_FAILED = 'Unable to connect to the server!'

P1ROUND = 'Player 1 Round'
P2ROUND = 'Player 2 Round'
P1WIN = 'Player 1 Win'
P2WIN = 'Player 2 Win'
DRAWGAME = 'Draw Game'

RECORD = '%d Win %d Lose %d Draw'
QUIT_BUTTON_CAPTION = 'Quit'
QUIT_MESSAGE = 'Are you sure you want to quit?'
USER_QUIT = 'The other user has lost his connection. The game will be closed.'

