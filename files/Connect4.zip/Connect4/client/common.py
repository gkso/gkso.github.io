#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

""" Common used functions. """

import pygame

from log import logger

def load_image(filename):
    """Load image file and return image object"""
    try:
        image = pygame.image.load(filename)
        if image.get_alpha() is None:
            image = image.convert()
        else:
            image = image.convert_alpha()
    except pygame.error, message:
        logger.error(message)
        raise SystemExit, message
    return image

def load_sound(filename):
    """Load sound file and return sound object"""
    class NoneSound:
        def play(self): pass
    if not pygame.mixer:
        return NoneSound()
    try:
        sound = pygame.mixer.Sound(filename)
    except pygame.error, message:
        logger.warn(message)
        #raise SystemExit, message
        return NoneSound()
    return sound