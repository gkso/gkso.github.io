#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/2

""" C/S network communication module """

import asyncore
import socket

import logging

log = logging.getLogger("NetworkLog")
log.setLevel(logging.DEBUG)
#formatter = logging.Formatter("[%(name)s] %(created)-15s %(levelname)8s %(thread)d %(message)s")
#handler = logging.StreamHandler()
#handler.setFormatter(formatter)
#log.addHandler(handler)

from network_messages import *


class NetworkException(Exception):
    """ An error occurs during network operation """

########################################################################
class ClientHandler(asyncore.dispatcher):
    """Handle client-side messages"""

    #----------------------------------------------------------------------
    def __init__(self, server_ip, server_port):
        """Constructor"""
        asyncore.dispatcher.__init__(self)
        self.server_ip = server_ip
        self.server_port = server_port
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setblocking(1)
        self.socket.settimeout(1)
        try:
            self.connect((server_ip, server_port))
        except:
            log.error('Unable to connect to server %s:%d.' % (server_ip, server_port))
            raise NetworkException('Failed to connect to server')
        if not self.connected:
            log.error('Unable to connect to server %s:%d.' % (server_ip, server_port))
            raise NetworkException('Failed to connect to server')
        self.socket.setblocking(0)
        self.raw_message = Message()
        self.events = []

    #----------------------------------------------------------------------
    def handle_read(self):
        """"""
        #log.debug('ServerHandler::handle_read')
        data = self.recv(1024)
        #log.debug('Recv Len: %d Data:\n%s' % len(data))

        while len(data) != 0:
            try:
                data = self.raw_message.fill(data)
            except MalformedMessageError:
                log.warning("Malformed message recved. Connection tear down.")
                self.close()
                return

            # the entire message has been received
            if self.raw_message.completed:
                log.debug("recv message length: %d" % self.raw_message.length)
                message = MessageFactory.decode(str(self.raw_message.content))
                log.debug("%s:\n%s" % (message.DESCRIPTOR.name, message))
                self.handle_message(message)
                self.raw_message = Message()

    #----------------------------------------------------------------------
    def handle_write(self):
        """"""
        pass

    #----------------------------------------------------------------------
    def handle_connect(self):
        """"""
        pass

    #----------------------------------------------------------------------
    def handle_close(self):
        """"""
        pass

    #----------------------------------------------------------------------
    def handle_message(self, message):
        """"""
        if isinstance(message, UserLoginResponse):
            # handle UserLoginResponse message
            pass
        elif isinstance(message, GetUserListResponse):
            # handle GetUserListResponse message
            pass
        elif isinstance(message, GetGameListResponse):
            # handle GetGameListResponse message
            pass
        elif isinstance(message, StartGame):
            # handle StartGame message
            event = GameStartEvent(message.move_first)
            self.events.append(event)
        elif isinstance(message, PutChessResponse):
            # handle PutChessResponse message
            if message.result_code != 0:
                log.warn('PutChessResponse.result_code = %d' % message.result_code)
            else:
                event = PutChessResponseEvent(message.status)
                self.events.append(event)
        elif isinstance(message, PutChessNotification):
            # handle PutChessNotification message
            event = PutChessNotificationEvent(message.row, message.column, message.status)
            self.events.append(event)
        elif isinstance(message, TerminateGame):
            # handle TerminateGame message
            event = TerminateGameEvent(message.reason)
            self.events.append(event)

    #----------------------------------------------------------------------
    def get_events(self):
        """"""
        if self.events:
            events = self.events
            self.events = []
            return events
        else:
            return []

    #----------------------------------------------------------------------
    def send_msg(self, message):
        """Encode a message and send it through socket"""
        msg_str = MessageFactory.encode(message)
        try:
            self.send(struct.pack('!I', len(msg_str)))
            self.send(MessageFactory.encode(message))
        except Exception, e:
            self.server.user_logout(self.client_id)
            return False
        return True

    #----------------------------------------------------------------------
    def user_login(self, user_name, avatar_idx):
        """Send user information to the server"""
        msg = UserLogin()
        msg.user_name = user_name
        msg.avatar_idx = avatar_idx
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def get_user_list(self):
        """Get all online users"""
        msg = GetUserList()
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def get_game_list(self):
        """Get all opening games"""
        msg = GetGameList()
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def ready(self):
        """Send ready message"""
        msg = Ready()
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def put_chess(self, row, column):
        """Send put chess message"""
        msg = PutChess()
        msg.row = row
        msg.column = column
        self.send_msg(msg)



########################################################################
class Event:
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""

########################################################################
class GameStartEvent(Event):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, move_first):
        """Constructor"""
        self.move_first = move_first

########################################################################
class PutChessResponseEvent(Event):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, status):
        """Constructor"""
        self.status = status

########################################################################
class PutChessNotificationEvent(Event):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, row, column, status):
        """Constructor"""
        self.row = row
        self.column = column
        self.status = status

########################################################################
class TerminateGameEvent(Event):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, reason):
        """Constructor"""
        self.reason = reason










