#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/31

""" Module used to loads images and sounds into the memory. """

import os
import sys

import pygame

import constants
from log import logger
from common import *


########################################################################
class Resources:
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self.initialized = False
        self.__load_images()
        self.__load_sounds()
        self.initialized = True

    #----------------------------------------------------------------------
    def __load_images(self):
        """"""
        # start screen
        self.game_title = load_image(constants.GAME_TITLE_IMAGE_FILE)
        self.hand = load_image(constants.HAND_IMAGE_FILE)
        # in game
        self.background = load_image(constants.BACKGROUND_IMAGE_FILE)
        self.chessboard = load_image(constants.CHESSBOARD_IMAGE_FILE)
        self.chesses = [load_image(constants.CHESS1_IMAGE_FILE),
                        load_image(constants.CHESS2_IMAGE_FILE)]
        self.player_rect = load_image(constants.PLAYER_RECT_IMAGE_FILE)
        self.message_bar = pygame.surface.Surface((pygame.display.get_surface().get_width(), 40))
        self.message_bar.fill((64, 64, 64))
        self.arrow = load_image(constants.ARROW_IMAGE_FILE)
        # load avatars
        self.avatars = []
        files = os.listdir(constants.AVATAR_DIR)
        for f in files:
            if f.endswith('.jpg'):
                filepath = os.path.join(constants.AVATAR_DIR, f)
                if os.path.isfile(filepath):
                    avatar_img = load_image(filepath)
                    # resize
                    avatar_img = pygame.transform.scale(avatar_img, (96, 96))
                    if avatar_img is not None:
                        self.avatars.append(avatar_img)

    #----------------------------------------------------------------------
    def __load_sounds(self):
        """"""
        #self.bgm = load_sound(constants.BACKGROUND_MUSIC_FILE)
        self.menu_move_sound = load_sound(constants.MENU_MOVE_SOUND_FILE)
        self.menu_click_sound = load_sound(constants.MENU_CLICK_SOUND_FILE)

resources = Resources()