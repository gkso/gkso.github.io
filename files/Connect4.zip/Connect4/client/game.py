#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

""" Connect4 game logic and game data """

import sys
import asyncore

import pygame
from pygame.locals import *

import constants
import strings
from log import logger
from objects import *
from gui import *
from network import *

START, P1ROUND, P2ROUND, P1WIN, P2WIN, DRAW = range(6)

screen = pygame.display.get_surface()
if not screen:
    log.error('No screen found!.')
    sys.exit(1)

clock = pygame.time.Clock()


########################################################################
class StartScreen:
    """The first screen when game starts. User may choose local game or
    game from the menu."""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self.font = pygame.font.Font(constants.MESSAGE_FONT, 32)
        self.running = True

    #----------------------------------------------------------------------
    def start(self):
        """"""
        while self.running:
            choice = self.start_screen()
            if choice == 1:
                # User choose 'Local Game'
                choice = self.local_game_screen()
                if choice == 1:
                    # User choose 'Player V.S. Player'
                    game = Connect4LocalGame()
                    game.start()
                    continue
                elif choice == 2:
                    # User choose 'Player V.S. Computer'
                    game = Connect4LocalGame(PLAYER, COMPUTER)
                    game.start()
                    continue
                elif choice == 3:
                    # User choose 'Back'
                    continue
            elif choice == 2:
                # User choose 'Network Game'
                choice = self.network_game_screen()
                if choice == 1:
                    # User choose 'Back'
                    continue
                elif choice == 2:
                    # Pair with another network player successfully
                    if self.move_first:
                        game = Connect4NetworkGame(self.handler, 1)
                    else:
                        game = Connect4NetworkGame(self.handler, 2)
                    game.start()
            elif choice == 3:
                # User choose 'Quit'
                break

        logger.info("Game Exit.")

    #----------------------------------------------------------------------
    def start_screen(self):
        """Show start screen, user should select an entry from the menu.
        Return user's choice."""
        game_title = resources.game_title
        screen.fill((0, 0, 0))
        # draw game title
        screen.blit(game_title, (screen.get_rect().w/2-game_title.get_rect().w/2, 50))
        # draw 1st-level menu:
        # 1. Local Game
        # 2. Network Game
        # 3. Quit
        menu_entries = (strings.LOCAL_GAME, strings.NETWORK_GAME, strings.QUIT_GAME)
        menu_pos = (280, 320)
        for i in range(len(menu_entries)):
            text = self.font.render(menu_entries[i], True, constants.COLOR_WHITE)
            screen.blit(text, (menu_pos[0], menu_pos[1]+i*40))
        # create hand sprite
        sprites = pygame.sprite.RenderUpdates()
        hand = Hand((menu_pos[0] - 100, menu_pos[1]))
        sprites.add(hand)
        # get user choice
        choice = 0
        index = 1
        while not choice:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                elif event.type == KEYUP:
                    if event.key == K_UP:
                        if index > 1:
                            index -= 1
                            hand.rect.top -= 40
                            resources.menu_move_sound.play()
                    elif event.key == K_DOWN:
                        if index < len(menu_entries):
                            index += 1
                            hand.rect.top += 40
                            resources.menu_move_sound.play()
                    elif event.key == K_RETURN or event.key == K_SPACE:
                        choice = index
                        resources.menu_click_sound.play()
            sprites.clear(screen, lambda surf, rect: surf.fill((0,0,0), rect))
            sprites.update()
            sprites.draw(screen)
            pygame.display.update()
            clock.tick(30)
        return choice

    #----------------------------------------------------------------------
    def local_game_screen(self):
        """Show local game screen, user should select an entry from the menu.
        Return user's choice."""
        game_title = resources.game_title
        screen.fill((0, 0, 0))
        # draw game title
        screen.blit(game_title, (screen.get_rect().w/2-game_title.get_rect().w/2, 50))
        # draw 2nd-level menu:
        # 1. Player V.S. Player
        # 2. Player V.s. Computer
        # 3. Back
        menu_entries = (strings.PVP, strings.PVC, strings.BACK)
        menu_pos = (280, 320)
        for i in range(len(menu_entries)):
            text = self.font.render(menu_entries[i], True, constants.COLOR_WHITE)
            screen.blit(text, (menu_pos[0], menu_pos[1]+i*40))
        # create hand sprite
        sprites = pygame.sprite.RenderUpdates()
        hand = Hand((menu_pos[0] - 100, menu_pos[1]))
        sprites.add(hand)
        # get user choice
        choice = 0
        index = 1
        while not choice:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                elif event.type == KEYUP:
                    if event.key == K_UP:
                        if index > 1:
                            index -= 1
                            hand.rect.top -= 40
                            resources.menu_move_sound.play()
                    elif event.key == K_DOWN:
                        if index < len(menu_entries):
                            index += 1
                            hand.rect.top += 40
                            resources.menu_move_sound.play()
                    elif event.key == K_RETURN or event.key == K_SPACE:
                        choice = index
                        resources.menu_click_sound.play()
            sprites.clear(screen, lambda surf, rect: surf.fill((0,0,0), rect))
            sprites.update()
            sprites.draw(screen)
            pygame.display.update()
            clock.tick(30)
        return choice

    #----------------------------------------------------------------------
    def network_game_screen(self):
        """Show network game screen, user should wait for another player,
        or choose to go back."""
        screen.fill((0, 0, 0))
        # draw 'connect to ...' in the center of screen
        text = self.font.render(strings.CONNECT_TO, True, constants.COLOR_WHITE)
        text_rect = text.get_rect(centerx=screen.get_rect().w/2, centery=200)
        screen.blit(text, text_rect)
        pygame.display.update()
        # create client handler
        handler = None
        try:
            handler = ClientHandler(constants.SERVER_IP, constants.SERVER_PORT)
            # send login message
            handler.user_login('Player X', 0)
            handler.ready()
            screen.fill((0, 0, 0))
            # draw 'waiting for ...' in the center of screen
            text = self.font.render(strings.WAITING_FOR, True, constants.COLOR_WHITE)
            text_rect = text.get_rect(centerx=screen.get_rect().w/2, centery=200)
            screen.blit(text, text_rect)
        except NetworkException, e:
            screen.fill((0, 0, 0))
            text = self.font.render(strings.CONNECT_FAILED, True, constants.COLOR_WHITE)
            text_rect = text.get_rect(centerx=screen.get_rect().w/2, centery=200)
            screen.blit(text, text_rect)

        # draw 'Back' menu entry
        text = self.font.render(strings.BACK, True, constants.COLOR_WHITE)
        screen.blit(text, (280, 320))
        pygame.display.update()
        # create hand sprite
        sprites = pygame.sprite.RenderUpdates()
        hand = Hand((180, 320))
        sprites.add(hand)

        # get choice
        choice = 0
        index = 1
        while not choice:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                elif event.type == KEYUP:
                    if event.key == K_RETURN or event.key == K_SPACE:
                        choice = index
                        resources.menu_click_sound.play()
                        if handler: handler.close()

            sprites.clear(screen, lambda surf, rect: surf.fill((0,0,0), rect))
            sprites.update()
            sprites.draw(screen)
            pygame.display.update()
            # receive network event
            asyncore.loop(timeout=0.01, count=1)
            if handler:
                for event in handler.get_events():
                    if isinstance(event, GameStartEvent):
                        choice = 2
                        self.move_first = event.move_first
                        self.handler = handler

            clock.tick(30)
        return choice

'''
    #----------------------------------------------------------------------
    def get_choice(self, list_, pos):
        """Draw a list on the screen, get user's choice."""
        for i in range(len(list_)):
            text = self.font.render(list_[i], True, constants.COLOR_WHITE)
            screen.blit(text, (pos[0], pos[1]+i*40))

        sprites = pygame.sprite.RenderUpdates()
        hand = Hand((pos[0] - 100, pos[1]))
        sprites.add(hand)

        choice = 0
        index = 1
        while not choice:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                elif event.type == KEYUP:
                    if event.key == K_UP:
                        if index > 1:
                            index -= 1
                            hand.rect.top -= 40
                    elif event.key == K_DOWN:
                        if index < len(list_):
                            index += 1
                            hand.rect.top += 40
                    elif event.key == K_RETURN or event.key == K_SPACE:
                        choice = index
            sprites.clear(screen, lambda surf, rect: surf.fill((0,0,0), rect))
            sprites.update()
            sprites.draw(screen)
            pygame.display.update()
            clock.tick(30)
        return choice
'''

PLAYER, COMPUTER = range(2)

########################################################################
class Connect4LocalGame:
    """"""

    #----------------------------------------------------------------------
    def __init__(self, p1_type=PLAYER, p2_type=PLAYER):
        """Constructor"""
        self.gamedata = GameData()
        self.p1_type = p1_type
        self.p2_type = p2_type

        self.allsprites = pygame.sprite.LayeredUpdates(default_layer=1)
        self.status = START

    #----------------------------------------------------------------------
    def set_layout(self):
        """"""
        self.chessboard = ChessBoard((270, 120))
        self.arrow = Arrow((0, 0))
        self.arrow.moveto(999999, 999999)
        self.p1_rect = PlayerRect((60, 120), 0)
        self.p2_rect = PlayerRect((60, 285), 1)
        self.msg_bar = MessageBar((0, 20))
        self.quit_button = Button((70, 460))
        self.quit_button.resize(137, 40)
        self.quit_button.set_caption('Quit')

    #----------------------------------------------------------------------
    def set_data(self):
        """"""
        self.p1_rect.set_name(self.gamedata.p1_name)
        self.p1_rect.set_avatar(self.gamedata.p1_avatar_idx)
        self.p1_rect.set_record(self.gamedata.p1_record)
        self.p1_rect.redraw()
        self.p2_rect.set_name(self.gamedata.p2_name)
        self.p2_rect.set_avatar(self.gamedata.p2_avatar_idx)
        self.p2_rect.set_record(self.gamedata.p2_record)
        self.p2_rect.redraw()
        self.msg_bar.set_text('Game Started')

    #----------------------------------------------------------------------
    def start(self):
        """"""
        # Play BGM
        bgms = ("res\\bgm.mid", "res\\bgm1.mid", "res\\bgm2.mid")
        import random
        pygame.mixer.music.load(bgms[random.Random().randint(0, 2)])
        pygame.mixer.music.play(-1)
        # Call mainloop
        self.mainloop()

    #----------------------------------------------------------------------
    def get_first_empty_slot(self, column):
        """"""
        row = -1
        for i in range(constants.CHESSBOARD_ROW-1, -1, -1):
            if self.gamedata.matrix[i][column] == 0:
                row = i
                break
        return row, column

    #----------------------------------------------------------------------
    def put_chess(self, player_idx, row, column):
        """Put the chess in the specific position"""
        logger.debug("Player %d put a chess on (%d, %d)." % (player_idx, row, column))
        self.gamedata.matrix[row][column] = player_idx
        self.gamedata.steps.append((row, column))
        x, y = self.pos2cord((row, column))
        chess = Chess((x, self.chessboard.rect.top), (x, y), player_idx-1)
        self.allsprites.add(chess, layer=0)

        # send message to server
        # self.socket.send_put_chess(row, column)

    #----------------------------------------------------------------------
    def check_win(self, player_idx):
        """Check if the player has win the game"""
        pass

    #----------------------------------------------------------------------
    def check_win_after_put_chess(self, player_idx, row, column):
        """Check if the player has win after putting a chess"""
        # check row
        left = right = 0
        c = column - 1
        while c >= 0 and self.gamedata.matrix[row][c] == player_idx:
            left = left + 1
            c = c - 1
        c = column + 1
        while c < constants.CHESSBOARD_COL and self.gamedata.matrix[row][c] == player_idx:
            right = right + 1
            c = c + 1
        if left + right + 1 >= 4: # more than four in a row!
            # player win
            logger.info("Player %d wins!" % player_idx)
            return True

        # check column
        up = down = 0
        r = row - 1
        while r >= 0 and self.gamedata.matrix[r][column] == player_idx:
            up = up + 1
            r = r - 1
        r = row + 1
        while r < constants.CHESSBOARD_ROW and self.gamedata.matrix[r][column] == player_idx:
            down = down + 1
            r = r + 1
        if up + down + 1 >= 4: # more than four in a column!
            # player win
            logger.info("Player %d win!" % player_idx)
            return True

        # check left-up to right-down diagonal
        leftup = rightdown = 0
        r = row - 1
        c = column - 1
        while r >= 0 and c >= 0 and self.gamedata.matrix[r][c] == player_idx:
            leftup = leftup + 1
            r = r - 1
            c = c - 1
        r = row + 1
        c = column + 1
        while r < constants.CHESSBOARD_ROW and c < constants.CHESSBOARD_COL and \
              self.gamedata.matrix[r][c] == player_idx:
            rightdown = rightdown + 1
            r = r + 1
            c = c + 1
        if leftup + rightdown + 1 >= 4: # more than four in a lu-rd diagonal
            # player win
            logger.info("Player %d win!" % player_idx)
            return True

        # check right-top to left-down diagonal
        rightup = leftdown = 0
        r = row - 1
        c = column + 1
        while r >= 0 and c < constants.CHESSBOARD_COL and \
              self.gamedata.matrix[r][c] == player_idx:
            rightup = rightup + 1
            r = r - 1
            c = c + 1
        r = row + 1
        c = column - 1
        while r < constants.CHESSBOARD_ROW and c >= 0 and \
              self.gamedata.matrix[r][c] == player_idx:
            leftdown = leftdown + 1
            r = r + 1
            c = c - 1
        if rightup + leftdown + 1 >= 4: # more than four in a ru-ld diagonal
            # player win
            logger.info("Player %d win!" % player_idx)
            return True

        return False

    #----------------------------------------------------------------------
    def change_status(self, status):
        """Change game status"""
        if status == self.status:
            return
        if status == P1ROUND:
            self.gamedata.cur_player_idx = 1
            self.msg_bar.set_text(strings.P1ROUND)
        elif status == P2ROUND:
            self.gamedata.cur_player_idx = 2
            self.msg_bar.set_text(strings.P2ROUND)
        elif status == P1WIN:
            self.msg_bar.set_text(strings.P1WIN)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p1_record[0] += 1 # p1 win + 1
            self.gamedata.p2_record[1] += 1 # p2 lose + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        elif status == P2WIN:
            self.msg_bar.set_text(strings.P2WIN)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p2_record[0] += 1 # p2 win + 1
            self.gamedata.p1_record[1] += 1 # p2 lose + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        elif status == DRAW:
            self.msg_bar.set_text(strings.DRAWGAME)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p1_record[2] += 1 # p1 draw + 1
            self.gamedata.p2_record[2] += 1 # p2 draw + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        self.status = status

    #----------------------------------------------------------------------
    def mainloop(self):
        """Main loop for a local game"""
        # blit background image
        screen.blit(resources.background, (0, 0))
        # put components in place
        self.set_layout()
        self.set_data()
        # create sprite group
        self.allsprites.add(self.arrow)
        self.allsprites.add(self.chessboard)
        self.allsprites.add(self.p1_rect)
        self.allsprites.add(self.p2_rect)
        self.allsprites.add(self.msg_bar)
        self.allsprites.add(self.quit_button)

        # assume player 1 first
        self.change_status(P1ROUND)

        quit_dlg = None
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                if quit_dlg:
                    # handle quit dialog only!
                    if quit_dlg.handle_event(event):
                        res = quit_dlg.get_result()
                        if res == 0: # pressed OK!
                            pygame.mixer.music.stop()
                            return
                        elif res == 1: # pressed Cancel!
                            self.allsprites.remove(quit_dlg)
                            quit_dlg = None
                else:
                    if self.quit_button.handle_event(event):
                        # Quit button pressed!
                        quit_dlg = OkCancelDialog((0, 0))
                        quit_dlg.set_text(strings.QUIT_MESSAGE)
                        quit_dlg.rect.centerx = screen.get_rect().w/2
                        quit_dlg.rect.centery = screen.get_rect().h/2
                        self.allsprites.add(quit_dlg, layer=2)

                    elif (self.status == P1ROUND and self.p1_type == PLAYER) or \
                         (self.status == P2ROUND and self.p2_type == PLAYER):
                        # Player Round
                        if event.type == MOUSEMOTION:
                            # MOVE-ARROW
                            mouse = pygame.mouse.get_pos()
                            row, column = self.cord2pos(mouse)
                            #print('Row: %d Col: %d' % (row, column))
                            if column != -1:
                                # if in player's turn
                                if column != self.arrow.column:
                                    x = self.pos2cord((row, column))[0] - 20
                                    y = self.chessboard.rect.top - 30
                                    self.arrow.moveto(x, y)
                                    self.arrow.column = column
                                #a, b = self.pos2cord((row, column))
                                #print('(%d, %d) - (%d, %d)' % (mouse[0], mouse[1], a, b))
                            else:
                                self.arrow.moveto(999999, 999999)
                        elif event.type == MOUSEBUTTONDOWN and event.button == 1:
                            # RECORD-POS
                            mouse = pygame.mouse.get_pos()
                            mouse_down_pos = mouse
                        elif event.type == MOUSEBUTTONUP and event.button == 1:
                            # PUT-A-CHESS
                            mouse = pygame.mouse.get_pos()
                            row, column = self.cord2pos(mouse)
                            row_0, column_0 = self.cord2pos(mouse_down_pos)
                            if row != row_0 or column != column_0:
                                # mouse down pos != mouse up pos, then ignore
                                continue
                            if row != -1 and column != -1:
                                # check the position
                                row = self.get_first_empty_slot(column)[0]
                                if row != -1: # current column is not full
                                    # put a chess
                                    self.put_chess(self.gamedata.cur_player_idx, row, column)
                                    # check if win
                                    if self.check_win_after_put_chess(
                                        self.gamedata.cur_player_idx, row, column):
                                        if self.status == P1ROUND:
                                            self.change_status(P1WIN)
                                        elif self.status == P2ROUND:
                                            self.change_status(P2WIN)
                                    # check if draw
                                    elif len(self.gamedata.steps) == 42:
                                        self.change_status(DRAW)
                                    else:
                                        # turn to another player
                                        if self.status == P1ROUND:
                                            self.change_status(P2ROUND)
                                        elif self.status == P2ROUND:
                                            self.change_status(P1ROUND)
                    else:
                        self.arrow.moveto(999999, 999999) # hide arrow

            # update all sprites
            self.allsprites.update()
            screen.blit(resources.background, (0, 0))
            self.allsprites.draw(screen)
            pygame.display.flip()

            clock.tick(30)

    #----------------------------------------------------------------------
    def cord2pos(self, cord):
        """Convert a (x, y) coordinate to the (row, column) position on chessboard,
        row and column index starts from 0. If out of chessboard, return (-1, -1)."""
        x, y = cord
        if self.chessboard.rect.collidepoint(cord):
            column = (x - self.chessboard.rect.left - 30) // 60
            if column < 0: column = 0
            if column >= constants.CHESSBOARD_COL:
                column = constants.CHESSBOARD_COL - 1
            row = (y - self.chessboard.rect.top - 8) // 60
            if row < 0: row = 0
            if row >= constants.CHESSBOARD_ROW:
                row = constants.CHESSBOARD_ROW - 1
            return (row, column)
        else:
            return (-1, -1)

    #----------------------------------------------------------------------
    def pos2cord(self, pos):
        """Convert a (row, column) position to the (x, y) coordinate on screen,
        the coordinate points to the center of the slot. """
        row, column = pos
        if (row >= 0 and row < constants.CHESSBOARD_ROW) and \
           (column >= 0 and column < constants.CHESSBOARD_COL):
            x = self.chessboard.rect.left + column * 60 + 55
            y = self.chessboard.rect.top + row * 60 + 35
            return (x, y)
        else:
            return (0, 0)

########################################################################
class Connect4NetworkGame:
    """"""

    #----------------------------------------------------------------------
    def __init__(self, handler, order):
        """Constructor"""
        self.handler = handler
        self.order = order
        self.gamedata = GameData()
        self.allsprites = pygame.sprite.LayeredUpdates(default_layer=1)
        self.status = START

    #----------------------------------------------------------------------
    def set_layout(self):
        """"""
        self.chessboard = ChessBoard((270, 120))
        self.arrow = Arrow((0, 0))
        self.arrow.moveto(999999, 999999)
        self.p1_rect = PlayerRect((60, 120), 0)
        self.p2_rect = PlayerRect((60, 285), 1)
        self.msg_bar = MessageBar((0, 20))
        self.quit_button = Button((70, 460))
        self.quit_button.resize(137, 40)
        self.quit_button.set_caption('Quit')

    #----------------------------------------------------------------------
    def set_data(self):
        """"""
        self.p1_rect.set_name(self.gamedata.p1_name)
        self.p1_rect.set_avatar(self.gamedata.p1_avatar_idx)
        self.p1_rect.set_record(self.gamedata.p1_record)
        self.p1_rect.redraw()
        self.p2_rect.set_name(self.gamedata.p2_name)
        self.p2_rect.set_avatar(self.gamedata.p2_avatar_idx)
        self.p2_rect.set_record(self.gamedata.p2_record)
        self.p2_rect.redraw()
        self.msg_bar.set_text('Game Started')

    #----------------------------------------------------------------------
    def change_status(self, status):
        """Change game status"""
        if status == self.status:
            return
        if status == P1ROUND:
            self.gamedata.cur_player_idx = 1
            self.msg_bar.set_text(strings.P1ROUND)
        elif status == P2ROUND:
            self.gamedata.cur_player_idx = 2
            self.msg_bar.set_text(strings.P2ROUND)
        elif status == P1WIN:
            self.msg_bar.set_text(strings.P1WIN)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p1_record[0] += 1 # p1 win + 1
            self.gamedata.p2_record[1] += 1 # p2 lose + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        elif status == P2WIN:
            self.msg_bar.set_text(strings.P2WIN)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p2_record[0] += 1 # p2 win + 1
            self.gamedata.p1_record[1] += 1 # p2 lose + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        elif status == DRAW:
            self.msg_bar.set_text(strings.DRAWGAME)
            self.arrow.moveto(999999, 999999)
            self.gamedata.p1_record[2] += 1 # p1 draw + 1
            self.gamedata.p2_record[2] += 1 # p2 draw + 1
            self.p1_rect.set_record(self.gamedata.p1_record)
            self.p1_rect.redraw()
            self.p2_rect.set_record(self.gamedata.p2_record)
            self.p2_rect.redraw()
        self.status = status

    #----------------------------------------------------------------------
    def get_first_empty_slot(self, column):
        """"""
        row = -1
        for i in range(constants.CHESSBOARD_ROW-1, -1, -1):
            if self.gamedata.matrix[i][column] == 0:
                row = i
                break
        return row, column

    #----------------------------------------------------------------------
    def put_chess(self, player_idx, row, column):
        """Put the chess in the specific position"""
        logger.debug("Player %d put a chess on (%d, %d)." % (player_idx, row, column))
        self.gamedata.matrix[row][column] = player_idx
        self.gamedata.steps.append((row, column))
        x, y = self.pos2cord((row, column))
        chess = Chess((x, self.chessboard.rect.top), (x, y), player_idx-1)
        self.allsprites.add(chess, layer=0)

        # send PutChess message to server
        self.handler.put_chess(row, column)

    #----------------------------------------------------------------------
    def start(self):
        """"""
        # Play BGM
        bgms = ("res\\bgm.mid", "res\\bgm1.mid", "res\\bgm2.mid")
        import random
        pygame.mixer.music.load(bgms[random.Random().randint(0, 2)])
        pygame.mixer.music.play(-1)
        # Call mainloop
        self.mainloop()

    #----------------------------------------------------------------------
    def mainloop(self):
        """Main loop for a network game"""
        # blit background image
        screen.blit(resources.background, (0, 0))
        # put components in place
        self.set_layout()
        self.set_data()
        # create sprite group
        self.allsprites.add(self.arrow)
        self.allsprites.add(self.chessboard)
        self.allsprites.add(self.p1_rect)
        self.allsprites.add(self.p2_rect)
        self.allsprites.add(self.msg_bar)
        self.allsprites.add(self.quit_button)

        # assume player 1 first
        self.change_status(P1ROUND)

        quit_dlg = None
        notification_dlg = None
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == QUIT: sys.exit()
                if quit_dlg:
                    # handle quit dialog only!
                    if quit_dlg.handle_event(event):
                        res = quit_dlg.get_result()
                        if res == 0: # pressed OK!
                            self.handler.close()
                            pygame.mixer.music.stop()
                            return
                        elif res == 1: # pressed Cancel!
                            self.allsprites.remove(quit_dlg)
                            quit_dlg = None
                elif notification_dlg:
                    # handle notification dialog only!
                    if notification_dlg.handle_event(event):
                        res = notification_dlg.get_result()
                        if res == 0: # pressed OK!
                            self.allsprites.remove(notification_dlg)
                            notification_dlg = None
                            self.handler.close()
                            pygame.mixer.music.stop()
                            return
                else:
                    if self.quit_button.handle_event(event):
                        # Quit button pressed!
                        quit_dlg = OkCancelDialog((0, 0))
                        quit_dlg.set_text(strings.QUIT_MESSAGE)
                        quit_dlg.rect.centerx = screen.get_rect().w/2
                        quit_dlg.rect.centery = screen.get_rect().h/2
                        self.allsprites.add(quit_dlg, layer=2)

                    elif (self.status == P1ROUND and self.order == 1) or \
                         (self.status == P2ROUND and self.order == 2):
                        # Player Round
                        if event.type == MOUSEMOTION:
                            # MOVE-ARROW
                            mouse = pygame.mouse.get_pos()
                            row, column = self.cord2pos(mouse)
                            #print('Row: %d Col: %d' % (row, column))
                            if column != -1:
                                # if in player's turn
                                if column != self.arrow.column:
                                    x = self.pos2cord((row, column))[0] - 20
                                    y = self.chessboard.rect.top - 30
                                    self.arrow.moveto(x, y)
                                    self.arrow.column = column
                                #a, b = self.pos2cord((row, column))
                                #print('(%d, %d) - (%d, %d)' % (mouse[0], mouse[1], a, b))
                            else:
                                self.arrow.moveto(999999, 999999)
                        elif event.type == MOUSEBUTTONDOWN and event.button == 1:
                            # RECORD-POS
                            mouse = pygame.mouse.get_pos()
                            mouse_down_pos = mouse
                        elif event.type == MOUSEBUTTONUP and event.button == 1:
                            # PUT-A-CHESS
                            mouse = pygame.mouse.get_pos()
                            row, column = self.cord2pos(mouse)
                            row_0, column_0 = self.cord2pos(mouse_down_pos)
                            if row != row_0 or column != column_0:
                                # mouse down pos != mouse up pos, then ignore
                                continue
                            if row != -1 and column != -1:
                                # check the position
                                row = self.get_first_empty_slot(column)[0]
                                if row != -1: # current column is not full
                                    # put a chess
                                    self.put_chess(self.gamedata.cur_player_idx, row, column)
                                    if self.order == 1:
                                        self.change_status(P2ROUND)
                                    elif self.order == 2:
                                        self.change_status(P1ROUND)

                    else:
                        self.arrow.moveto(999999, 999999) # hide arrow

            # update all sprites
            self.allsprites.update()
            screen.blit(resources.background, (0, 0))
            self.allsprites.draw(screen)
            pygame.display.flip()

            # handler network event
            asyncore.loop(timeout=0.01, count=1)
            for event in self.handler.get_events():
                if isinstance(event, PutChessResponseEvent):
                    logger.debug("PutChessResponse Event coming. status=%d" % event.status)
                    if event.status in (P1WIN, P2WIN, DRAW):
                        self.change_status(event.status)
                elif isinstance(event, PutChessNotificationEvent):
                    logger.debug("PutChessNotification Event coming. pos=(%d,%d), status=%d" % \
                                 (event.row, event.column, event.status))
                    if self.order == 1:
                        self.put_chess(2, event.row, event.column)
                    elif self.order == 2:
                        self.put_chess(1, event.row, event.column)
                    self.change_status(event.status)
                elif isinstance(event, TerminateGameEvent):
                    logger.debug("PutChessNotification Event coming. reason=%s" % event.reason)
                    if event.reason == 'USER_LOGOUT':
                        # The other user quit!
                        notification_dlg = OkDialog((0, 0))
                        notification_dlg.resize(640, 160)
                        notification_dlg.set_text(strings.USER_QUIT)
                        notification_dlg.rect.centerx = screen.get_rect().w/2
                        notification_dlg.rect.centery = screen.get_rect().h/2
                        self.allsprites.add(notification_dlg, layer=2)
                    elif event.reason == 'USER_WIN':
                        if self.order == 1:
                            self.change_status(P1WIN)
                        elif self.order == 2:
                            self.change_status(P2WIN)
                    elif event.reason == 'USER_LOSE':
                        if self.order == 1:
                            self.change_status(P2WIN)
                        elif self.order == 2:
                            self.change_status(P1WIN)

            clock.tick(30)

    #----------------------------------------------------------------------
    def cord2pos(self, cord):
        """Convert a (x, y) coordinate to the (row, column) position on chessboard,
        row and column index starts from 0. If out of chessboard, return (-1, -1)."""
        x, y = cord
        if self.chessboard.rect.collidepoint(cord):
            column = (x - self.chessboard.rect.left - 30) // 60
            if column < 0: column = 0
            if column >= constants.CHESSBOARD_COL:
                column = constants.CHESSBOARD_COL - 1
            row = (y - self.chessboard.rect.top - 8) // 60
            if row < 0: row = 0
            if row >= constants.CHESSBOARD_ROW:
                row = constants.CHESSBOARD_ROW - 1
            return (row, column)
        else:
            return (-1, -1)

    #----------------------------------------------------------------------
    def pos2cord(self, pos):
        """Convert a (row, column) position to the (x, y) coordinate on screen,
        the coordinate points to the center of the slot. """
        row, column = pos
        if (row >= 0 and row < constants.CHESSBOARD_ROW) and \
           (column >= 0 and column < constants.CHESSBOARD_COL):
            x = self.chessboard.rect.left + column * 60 + 55
            y = self.chessboard.rect.top + row * 60 + 35
            return (x, y)
        else:
            return (0, 0)


########################################################################
class GameData:
    """Record game data during a game"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""
        self.chess_set = 0
        self.p1_name = 'Player 1'
        self.p2_name = 'Player 2'
        self.p1_avatar_idx = 0
        self.p2_avatar_idx = 1
        self.p1_record = [0, 0, 0]
        self.p2_record = [0, 0, 0]

        self.cur_player_idx = 1 # player index start from 1!

        self.matrix = []
        for i in range(constants.CHESSBOARD_ROW):
            self.matrix.append([0] * constants.CHESSBOARD_COL)
        self.steps = []

    #----------------------------------------------------------------------
    def set_player_name(self, player_idx, name):
        """Set the name of a player"""
        if player_idx == 1:
            # player 1
            self.p1_name = name
        elif player_idx == 2:
            # player 2
            self.p2_name = name
        else:
            # wrong player index
            logger.debug('Wrong player index: ', player_idx)

    #----------------------------------------------------------------------
    def set_player_avatar(self, player_idx, avatar_idx):
        """Set the avatar of a player"""
        if player_idx == 1:
            # player 1
            self.p1_avatar_idx = avatar_idx # check avatar index?
        elif player_idx == 2:
            # player 2
            self.p2_avatar_idx = avatar_idx
        else:
            # wrong player index
            logger.debug('Wrong player index: ', player_idx)




