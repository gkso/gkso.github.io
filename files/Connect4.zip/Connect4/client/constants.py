#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

""" Constants. Most of them should NOT be changed, except server ip and port. """

import os

import pygame


SERVER_IP = '192.168.35.86'
SERVER_PORT = 38324

CHESSBOARD_ROW = 6
CHESSBOARD_COL = 7

WINDOW_SIZE = (800, 600)
BLACK = (0, 0, 0)

RESOURCE_DIR = "res"

GAME_TITLE_IMAGE_FILE = os.path.join(RESOURCE_DIR, "game_title.png")
HAND_IMAGE_FILE = os.path.join(RESOURCE_DIR, "hand.png")

BACKGROUND_IMAGE_FILE = os.path.join(RESOURCE_DIR, "background.jpg")
CHESSBOARD_IMAGE_FILE = os.path.join(RESOURCE_DIR, "chess_board.png")
CHESS1_IMAGE_FILE = os.path.join(RESOURCE_DIR, "chess1.png")
CHESS2_IMAGE_FILE = os.path.join(RESOURCE_DIR, "chess2.png")
PLAYER_RECT_IMAGE_FILE = os.path.join(RESOURCE_DIR, "player_rect.png")
MESSAGE_BAR_IMAGE_FILE = os.path.join(RESOURCE_DIR, "message_bar.png")
ARROW_IMAGE_FILE = os.path.join(RESOURCE_DIR, "arrow.png")

# GUI
BUTTON_IMAGE_FILE = os.path.join(RESOURCE_DIR, "button2.png")
DIALOG_BACKGROUND_IMAGE_FILE = os.path.join(RESOURCE_DIR, "dlg_bg.png")

AVATAR_DIR = os.path.join(RESOURCE_DIR, 'avatar')

BACKGROUND_MUSIC_FILE = os.path.join(RESOURCE_DIR, "bgm.wav")
MENU_MOVE_SOUND_FILE = os.path.join(RESOURCE_DIR, "move.wav")
MENU_CLICK_SOUND_FILE = os.path.join(RESOURCE_DIR, "click.wav")

FONT = os.path.join(RESOURCE_DIR, 'tahoma.ttf')
UI_FONT = os.path.join(RESOURCE_DIR, 'tahoma.ttf')
MESSAGE_FONT = os.path.join(RESOURCE_DIR, 'tahoma.ttf')

# colors
COLOR_BLACK = pygame.Color(0, 0, 0)
COLOR_WHITE = pygame.Color(255, 255, 255)
COLOR_RED = pygame.Color(255, 0, 0)
COLOR_GREEN = pygame.Color(0, 255, 0)
COLOR_BLUE = pygame.Color(0, 0, 255)