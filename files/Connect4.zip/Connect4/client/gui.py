#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/31

""" GUI objects """

import pygame
from pygame.locals import *

from common import *
import constants

if pygame.font is None:
    print("gui.py: Font module not found!")
    raise SystemExit


########################################################################
class TextInput(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""


class Button(pygame.sprite.Sprite):
    """"""
    def __init__(self, pos):
        pygame.sprite.Sprite.__init__(self)
        self.bg_image = load_image(constants.BUTTON_IMAGE_FILE)
        self.rect = self.bg_image.get_rect()
        self.image = pygame.surface.Surface(self.bg_image.get_size())
        self.image.blit(self.bg_image, self.rect)
        self.image.set_colorkey((0, 0, 0))
        self.font = pygame.font.Font(constants.UI_FONT, 16)
        self.pressing = False

        self.rect.topleft = pos
        self.normal_rect = self.rect
        self.pressing_rect = self.rect.move(5, 5)

    def set_caption(self, text):
        self.image.blit(self.bg_image, self.rect)
        text_surface = self.font.render(text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(centerx=self.rect.w/2,
                                          centery=self.rect.h/2)
        self.image.blit(text_surface, text_rect)

    def move(self, pos):
        self.rect.topleft = pos
        self.normal_rect = self.rect
        self.pressing_rect = self.rect.move(5, 5)

    def resize(self, width, height):
        pos = self.rect.topleft
        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        self.normal_rect = self.rect
        self.pressing_rect = self.rect.move(5, 5)

    def pressed(self, mouse):
        if mouse[0] > self.rect.topleft[0]:
            if mouse[1] > self.rect.topleft[1]:
                if mouse[0] < self.rect.bottomright[0]:
                    if mouse[1] < self.rect.bottomright[1]:
                        return True
                    else: return False
                else: return False
            else: return False
        else: return False

    def update(self):
        if self.pressing:
            self.rect = self.pressing_rect
        else:
            self.rect = self.normal_rect

    #----------------------------------------------------------------------
    def handle_event(self, event):
        """"""
        if event.type == MOUSEBUTTONDOWN and event.button == 1:
            mouse = pygame.mouse.get_pos()
            if self.pressed(mouse):
                self.pressing = True
                self.mouse_down_pos = mouse
        elif event.type == MOUSEBUTTONUP and event.button == 1:
            self.pressing = False
            mouse = pygame.mouse.get_pos()
            if self.pressed(mouse) and self.pressed(self.mouse_down_pos):
                #Button pressed
                return True
        return False


########################################################################
class Dialog(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        self.bg_image = load_image(constants.DIALOG_BACKGROUND_IMAGE_FILE)
        self.rect = self.bg_image.get_rect()
        self.image = pygame.surface.Surface(self.bg_image.get_size())
        self.image.blit(self.bg_image, self.rect)
        self.image.set_colorkey((0, 0, 0))
        self.font = pygame.font.Font(constants.UI_FONT, 16)
        self.text = ''
        self.result = None

    #----------------------------------------------------------------------
    def set_text(self, text):
        """"""
        self.text = text
        self.image.blit(self.bg_image, self.rect)
        text_surface = self.font.render(text, True, (255, 255, 255))
        text_rect = text_surface.get_rect(centerx=self.rect.w/2, y=40)
        self.image.blit(text_surface, text_rect)

    #----------------------------------------------------------------------
    def get_result(self):
        """"""
        return self.result


########################################################################
class OkDialog(Dialog):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        Dialog.__init__(self, pos)
        self.buttons = pygame.sprite.RenderUpdates()
        self.ok_button = Button((self.rect.w * 0.5 - 40, self.rect.h * 0.6 - 12))
        self.ok_button.resize(80, 25)
        self.ok_button.set_caption('OK')
        self.buttons.add(self.ok_button)

    #----------------------------------------------------------------------
    def resize(self, width, height):
        """"""
        self.bg_image = pygame.transform.scale(self.bg_image, (width, height))
        self.rect = self.bg_image.get_rect()
        self.image = pygame.surface.Surface((width, height))
        self.image.set_colorkey((0, 0, 0))
        self.set_text(self.text)
        self.ok_button.move((self.rect.w * 0.5 - 40, self.rect.h * 0.6 - 12))

    #----------------------------------------------------------------------
    def update(self):
        """"""
        bg_surf = pygame.surface.Surface(self.rect.size)
        bg_surf.blit(self.bg_image, (0, 0))
        self.buttons.clear(self.image, bg_surf)
        self.buttons.update()
        self.buttons.draw(self.image)

    #----------------------------------------------------------------------
    def handle_event(self, event):
        """"""
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse = pygame.mouse.get_pos()
            mouse = (mouse[0] - self.rect.x, mouse[1] - self.rect.y)
            if self.ok_button.pressed(mouse):
                self.ok_button.pressing = True
            self.mouse_down_pos = mouse
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.ok_button.pressing = False
            mouse = pygame.mouse.get_pos()
            mouse = (mouse[0] - self.rect.x, mouse[1] - self.rect.y)
            if self.ok_button.pressed(mouse) and self.ok_button.pressed(self.mouse_down_pos):
                self.result = 0
                return True
        return False


########################################################################
class OkCancelDialog(Dialog):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        Dialog.__init__(self, pos)
        self.buttons = pygame.sprite.RenderUpdates()
        self.ok_button = Button((self.rect.w * 0.3 - 40, self.rect.h * 0.6 - 12))
        self.ok_button.resize(80, 25)
        self.ok_button.set_caption('OK')
        self.cancel_button = Button((self.rect.w * 0.7 - 40, self.rect.h * 0.6 - 12))
        self.cancel_button.resize(80, 25)
        self.cancel_button.set_caption('Cancel')
        self.buttons.add(self.ok_button)
        self.buttons.add(self.cancel_button)

    #----------------------------------------------------------------------
    def resize(self, width, height):
        """"""
        self.bg_image = pygame.transform.scale(self.bg_image, (width, height))
        self.rect = self.bg_image.get_rect()
        self.image = pygame.surface.Surface((width, height))
        self.image.set_colorkey((0, 0, 0))
        self.set_text(self.text)
        self.ok_button.move((self.rect.w * 0.3 - 40, self.rect.h * 0.6 - 12))
        self.cancel_button.move((self.rect.w * 0.7 - 40, self.rect.h * 0.6 - 12))

    #----------------------------------------------------------------------
    def update(self):
        """"""
        bg_surf = pygame.surface.Surface(self.rect.size)
        bg_surf.blit(self.bg_image, (0, 0))
        self.buttons.clear(self.image, bg_surf)
        self.buttons.update()
        self.buttons.draw(self.image)

    #----------------------------------------------------------------------
    def handle_event(self, event):
        """"""
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            mouse = pygame.mouse.get_pos()
            mouse = (mouse[0] - self.rect.x, mouse[1] - self.rect.y)
            if self.ok_button.pressed(mouse):
                self.ok_button.pressing = True
            elif self.cancel_button.pressed(mouse):
                self.cancel_button.pressing = True
            self.mouse_down_pos = mouse
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.ok_button.pressing = False
            self.cancel_button.pressing = False
            mouse = pygame.mouse.get_pos()
            mouse = (mouse[0] - self.rect.x, mouse[1] - self.rect.y)
            if self.ok_button.pressed(mouse) and self.ok_button.pressed(self.mouse_down_pos):
                self.result = 0
                return True
            elif self.cancel_button.pressed(mouse) and self.cancel_button.pressed(self.mouse_down_pos):
                self.result = 1
                return True
        return False


if __name__ == '__main__':
    import sys
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    a = TextArea()

    while 1:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                if button.pressed(mouse):	#Button's pressed method is called
                    print ('button hit')
        pygame.display.update()