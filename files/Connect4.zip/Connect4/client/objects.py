#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/3

""" All pygame sprite objects that will be drawn on the screen. """

import pygame
from pygame.locals import *
#pygame.init()
#screen = pygame.display.set_mode((640, 480))

import constants
import strings
from log import logger
from common import *
from resource import resources


########################################################################
class Chess(pygame.sprite.Sprite):
    """class chess"""

    #----------------------------------------------------------------------
    def __init__(self, start_pos, end_pos, index):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        self.image = resources.chesses[index]
        self.rect = self.image.get_rect()
        self.rect.center = start_pos
        self.end_pos = end_pos
        self.falling = True
        self.falling_speed = 10

    #----------------------------------------------------------------------
    def update(self):
        """"""
        if self.falling:
            self.rect.top += self.falling_speed
            if self.rect.centery >= self.end_pos[1]:
                self.falling = False # stop falling
                self.rect.centery = self.end_pos[1]


########################################################################
class ChessBoard(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        self.image = resources.chessboard
        self.rect = self.image.get_rect()
        self.rect.topleft = pos


########################################################################
class Arrow(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        self.image = resources.arrow
        self.rect = self.image.get_rect()
        self.rect.topleft = pos

        self.up_bound = self.rect.top
        self.bottom_bound = self.rect.bottom + 10
        self.direction = 1
        self.column = -1

    #----------------------------------------------------------------------
    def moveto(self, x, y):
        """"""
        self.rect.topleft = x, y
        self.up_bound = self.rect.top
        self.bottom_bound = self.rect.bottom + 10

    #----------------------------------------------------------------------
    def set_visible(self, visible):
        """"""
        if visible:
            self.image.set_alpha(255)
        else:
            self.image.set_alpha(0)

    #----------------------------------------------------------------------
    def update(self):
        """"""
        self.rect.move_ip(0, self.direction)
        if self.rect.bottom > self.bottom_bound and self.direction > 0:
            self.direction = -self.direction
        elif self.rect.top < self.up_bound and self.direction < 0:
            self.direction = -self.direction


########################################################################
class MessageBar(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos, text_color=constants.COLOR_WHITE):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        if pygame.font is None:
            logger.error('No font module found!')
            raise SystemError
        self.font = pygame.font.Font(constants.MESSAGE_FONT, 32)

        self.bg_image = resources.message_bar
        self.image = pygame.surface.Surface(self.bg_image.get_size())
        self.image.set_alpha(192)
        self.image.blit(self.bg_image, (0, 0))
        self.rect = self.bg_image.get_rect()
        self.rect.topleft = pos
        self.text_color = text_color
        self.set_text('')  # must initialize

    #----------------------------------------------------------------------
    def set_text(self, text):
        """"""
        self.text = text
        self.text_surface = self.font.render(self.text, True, self.text_color)
        self.text_rect = self.text_surface.get_rect()
        self.text_rect.top = self.rect.h / 2 - self.text_rect.h / 2
        self.text_rect.right = self.rect.right - 10
        self.image.blit(self.bg_image, (0, 0))

    #----------------------------------------------------------------------
    def update(self):
        """"""
        self.image.blit(self.bg_image, self.text_rect)
        self.text_rect.move_ip(-4, 0)
        if self.text_rect.right < self.rect.left:
            self.text_rect.left = self.rect.right
        self.image.blit(self.text_surface, self.text_rect)


########################################################################
class PlayerRect(pygame.sprite.Sprite):
    TEXT_COLORS = (constants.COLOR_RED, constants.COLOR_BLUE)
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos, index):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)

        if pygame.font is None:
            logger.error('No font module found!')
            raise SystemError
        self.font = pygame.font.Font(constants.FONT, 12)

        self.bg_image = load_image(constants.PLAYER_RECT_IMAGE_FILE)
        self.image = pygame.surface.Surface(self.bg_image.get_size())
        self.image.set_alpha(192)
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.bg_image.get_rect()
        self.rect.topleft = pos
        self.image.blit(self.bg_image, (0, 0))

        self.index = index
        self.color = self.TEXT_COLORS[index]

        # initialize (necessary)
        self.set_name('')
        self.set_avatar(0)
        self.set_record((0, 0, 0))

    #----------------------------------------------------------------------
    def set_name(self, name):
        """"""
        self.name = name
        self.name_surface = self.font.render(name, True, self.color)

    #----------------------------------------------------------------------
    def set_avatar(self, avatar_idx):
        """"""
        self.avatar = resources.avatars[avatar_idx]

    #----------------------------------------------------------------------
    def set_record(self, record):
        """"""
        self.record = strings.RECORD % tuple(record)
        self.record_surface = self.font.render(self.record, True, self.color)

    #----------------------------------------------------------------------
    def redraw(self):
        """"""
        self.image.blit(self.bg_image, (0, 0))
        avatar_rect = self.avatar.get_rect(centerx=self.rect.w/2, top=20)
        self.image.blit(self.avatar, avatar_rect)
        name_rect = self.name_surface.get_rect(centerx=self.rect.w/2, top=117)
        self.image.blit(self.name_surface, name_rect)
        record_rect = self.record_surface.get_rect(centerx=self.rect.w/2, top=130)
        self.image.blit(self.record_surface, record_rect)

# START SCREEN

########################################################################
class Hand(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, pos):
        """Constructor"""
        pygame.sprite.Sprite.__init__(self)
        self.image = resources.hand
        self.rect = self.image.get_rect()
        self.rect.topleft = pos
        self.direction = 1
        self.left_bound = self.rect.left
        self.right_bound = self.rect.right + 20
        self.speed = 2

"""
    #----------------------------------------------------------------------
    def update(self):
        """"""
        if self.direction == 1:
            # moving towards right
            self.rect.left += self.speed
            if self.rect.right >= self.right_bound:
                self.direction = -1
        elif self.direction == -1:
            # moving towards left
            self.rect.left -= self.speed
            if self.rect.left <= self.left_bound:
                self.direction = 1
"""

########################################################################
class WinAnimation(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""

########################################################################
class LoseAnimation(pygame.sprite.Sprite):
    """"""

    #----------------------------------------------------------------------
    def __init__(self):
        """Constructor"""









if __name__ == '__main__':
    import sys
    screen.blit(resources.background, (0,0))
    pygame.display.flip()
    clock = pygame.time.Clock()

    all = pygame.sprite.RenderPlain()
    msg_bar = MessageBar((0, 10))
    msg_bar.set_text("Hello World!")
    all.add(msg_bar)
    all.add(ChessBoard((270, 120)))
    all.add(Arrow((100, 100)))

    while True:
        for event in pygame.event.get():
            if event.type == QUIT: sys.exit()

        all.update()
        screen.blit(resources.background, (0, 0))
        all.draw(screen)
        pygame.display.flip()
        clock.tick(30)







