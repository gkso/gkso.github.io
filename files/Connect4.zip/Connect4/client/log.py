#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/7/30

""" Logger class """

import logging

logger = logging.getLogger()

LOG_LEVEL = logging.DEBUG

logger.setLevel(LOG_LEVEL)
formatter = logging.Formatter('%(levelname)-8s %(asctime)s %(message)s')
formatter.datefmt = '%Y-%m-%d %H:%M:%S'
handler = logging.StreamHandler()
handler.setFormatter(formatter)
logger.addHandler(handler)


if __name__ == '__main__':
    logger.info('INFO')
    logger.debug('DEBUG')
    logger.error('ERROR')
    logger.warn('WARN')
