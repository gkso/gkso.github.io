#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/6

import cmd


########################################################################
class AdminCmd(cmd.Cmd):
    """"""

    #----------------------------------------------------------------------
    def __init__(self, server):
        """Constructor"""
        cmd.Cmd.__init__(self)
        self.server = server

    #----------------------------------------------------------------------
    def do_shutdown(self, line):
        """"""
        self.server.running = False
        return True

    #----------------------------------------------------------------------
    def do_list(self, line):
        """"""
        if line == 'user':
            if self.server.users:
                for user in self.server.users:
                    print user
            else:
                print 'No user online.'
        elif line == 'game':
            if self.server.games:
                for game in self.server.games:
                    print game
            else:
                print "There's no game currently."
        else:
            print 'list < user | game >'

    #----------------------------------------------------------------------
    def do_win(self, line):
        """"""
        user_id = line
        if user_id in self.server.users:
            user = self.server.users[user_id]
            if user.game:
                if user_id == user.game.user1.user_id:
                    opponent_user = user.game.user2
                elif user_id == user.game.user2.user_id:
                    opponent_user = user.game.user1
                else:
                    print "Seems that user is not in any game."
                    return
                user.handler.terminate_game("USER_WIN")
                opponent_user.handler.terminate_game("USER_LOSE")
            else:
                print "User is not in any game."
        else:
            print "User doesn't exists!"


    #----------------------------------------------------------------------
    def do_EOF(self, line):
        return True

    #----------------------------------------------------------------------
    def run(self):
        """"""
        self.cmdloop()





