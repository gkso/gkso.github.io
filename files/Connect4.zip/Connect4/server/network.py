#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/2

""" C/S network communication module """

import asyncore
import socket

import logging

log = logging.getLogger("")

from network_messages import *


########################################################################
class ServerHandler(asyncore.dispatcher):
    """Handle server-side messages"""

    #----------------------------------------------------------------------
    def __init__(self, client_sock, client_addr, server):
        """Constructor"""
        asyncore.dispatcher.__init__(self, client_sock)
        self.client_addr = client_addr
        self.client_id = None
        self.server = server
        self.raw_message = Message()

    #----------------------------------------------------------------------
    def handle_read(self):
        """"""
        #log.debug('ServerHandler::handle_read')
        data = self.recv(1024)
        #log.debug('Recv Len: %d Data:\n%s' % len(data))

        while len(data) != 0:
            try:
                data = self.raw_message.fill(data)
            except MalformedMessageError:
                log.warning("Malformed message recved: %s. " \
                            "Connection tear down." % str(self.client_addr))
                self.close()
                return

            # the entire message has been received
            if self.raw_message.completed:
                log.debug("recv message length: %d" % self.raw_message.length)
                message = MessageFactory.decode(str(self.raw_message.content))
                log.debug("%s:\n%s" % (message.DESCRIPTOR.name, message))
                self.handle_message(message)
                self.raw_message = Message()

    #----------------------------------------------------------------------
    def handle_write(self):
        """"""
        pass

    #----------------------------------------------------------------------
    def handle_close(self):
        """"""
        log.info('client disconnected: %s' % str(self.client_addr))
        if self.client_id:
            self.server.user_logout(self.client_id)
            self.server.waiting_queue.remove(self.client_id)
        self.close()

    #----------------------------------------------------------------------
    def handle_message(self, message):
        """"""
        if isinstance(message, UserLogin):
            # handle UserLogin message
            resp_msg = UserLoginResponse()
            #if message.user_name in self.server.users:
                ## user already exists, tear down the connection
                #resp_msg.result_code = 0 # login failed
                #self.send_msg(resp_msg)
                #self.socket.close()
            #else:
                #self.server.user_login(message.user_name, message.avatar_idx)
                #self.client_id = message.user_name
                #resp_msg.result_code = 1 # login succeded
                #self.send_msg(resp_msg)
            self.client_id = str(self.client_addr)
            self.server.user_login(self.client_id, message.avatar_idx, self)
            resp_msg.result_code = 1 # login succeded
            self.send_msg(resp_msg)
        elif isinstance(message, GetUserList):
            # handle GetUserList message
            pass
        elif isinstance(message, GetGameList):
            # handle GetGameList message
            pass
        elif isinstance(message, Ready):
            # handle Ready message
            self.server.user_ready(self.client_id)
        elif isinstance(message, PutChess):
            # handle PutChess message
            self.server.put_chess(self.client_id, message.row, message.column)

    #----------------------------------------------------------------------
    def send_msg(self, message):
        """Encode a message and send it through socket."""
        msg_str = MessageFactory.encode(message)
        try:
            self.send(struct.pack('!I', len(msg_str)))
            self.send(MessageFactory.encode(message))
        except Exception, e:
            self.server.user_logout(self.client_id)
            return False
        return True

    #----------------------------------------------------------------------
    def start_game(self, move_first):
        """Send start game message"""
        msg = StartGame()
        msg.move_first = move_first
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def put_chess_response(self, result_code, status):
        """"""
        msg = PutChessResponse()
        msg.result_code = result_code
        msg.status = status
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def put_chess_notification(self, row, column, status):
        """"""
        msg = PutChessNotification()
        msg.row = row
        msg.column = column
        msg.status = status
        self.send_msg(msg)

    #----------------------------------------------------------------------
    def terminate_game(self, reason):
        """"""
        msg = TerminateGame()
        msg.reason = reason
        self.send_msg(msg)


########################################################################
class ServerListener(asyncore.dispatcher):
    """"""
    max_client_num = 1000
    clients = []

    #----------------------------------------------------------------------
    def __init__(self, ip, port, server):
        """Constructor"""
        asyncore.dispatcher.__init__(self)
        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.bind((ip, port))
        self.listen(self.max_client_num)
        self.server = server
        log.info('server started at %s:%d' % (ip, port))

    #----------------------------------------------------------------------
    def handle_accept(self):
        """"""
        (conn_sock, client_address) = self.accept()
        log.info('client connected: %s' % str(client_address))
        self.clients.append(ServerHandler(conn_sock, client_address, self.server))

    #----------------------------------------------------------------------
    def handle_read(self):
        """"""
        log.debug('*Server* handle_read')
        buf = self.recv(1024)
        log.debug('Recv: %s' % buf)
        log.debug('Len: %d' % len(buf))

    #----------------------------------------------------------------------
    def start(self):
        """"""
        asyncore.loop()


if __name__ == '__main__':
    server = ServerListener('0.0.0.0', 38324)
    server.start()

    print 'Server exit.'





