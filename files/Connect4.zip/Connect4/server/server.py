#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:  Zhongjie Wang <wzj401@gmail.com>
# Created: 2012/8/3

import asyncore
import logging
import thread
import time

from network import ServerListener, ServerHandler
from admin import AdminCmd

log = logging.getLogger("")
log.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(created)-15s [%(levelname)8s] %(thread)d %(message)s")
handler = logging.StreamHandler()
#handler = logging.FileHandler('log.txt')
handler.setFormatter(formatter)
log.addHandler(handler)


START, P1ROUND, P2ROUND, P1WIN, P2WIN, DRAW = range(6)
CHESSBOARD_ROW = 6
CHESSBOARD_COL = 7

########################################################################
class User:
    """"""

    #----------------------------------------------------------------------
    def __init__(self, user_id, avatar_idx, handler):
        """Constructor"""
        self.user_id = user_id
        self.avatar_idx = avatar_idx
        self.handler = handler
        self.game = None

########################################################################
class Game:
    """"""

    #----------------------------------------------------------------------
    def __init__(self, user1, user2):
        """Constructor"""
        self.user1 = user1
        self.user2 = user2
        self.matrix = []
        for i in range(CHESSBOARD_ROW):
            self.matrix.append([0] * CHESSBOARD_COL)
        self.steps = []

        self.status = START

    #----------------------------------------------------------------------
    def check_pos(self, row, column):
        """"""
        if self.matrix[row][column] != 0:
            return False
        return True

    #----------------------------------------------------------------------
    def check_win_after_put_chess(self, player_idx, row, column):
        """Check if the player has win after putting a chess"""
        # check row
        left = right = 0
        c = column - 1
        while c >= 0 and self.matrix[row][c] == player_idx:
            left = left + 1
            c = c - 1
        c = column + 1
        while c < CHESSBOARD_COL and self.matrix[row][c] == player_idx:
            right = right + 1
            c = c + 1
        if left + right + 1 >= 4: # more than four in a row!
            # player win
            log.debug("Player %d wins!" % player_idx)
            return True

        # check column
        up = down = 0
        r = row - 1
        while r >= 0 and self.matrix[r][column] == player_idx:
            up = up + 1
            r = r - 1
        r = row + 1
        while r < CHESSBOARD_ROW and self.matrix[r][column] == player_idx:
            down = down + 1
            r = r + 1
        if up + down + 1 >= 4: # more than four in a column!
            # player win
            log.debug("Player %d win!" % player_idx)
            return True

        # check left-up to right-down diagonal
        leftup = rightdown = 0
        r = row - 1
        c = column - 1
        while r >= 0 and c >= 0 and self.matrix[r][c] == player_idx:
            leftup = leftup + 1
            r = r - 1
            c = c - 1
        r = row + 1
        c = column + 1
        while r < CHESSBOARD_ROW and c < CHESSBOARD_COL and \
              self.matrix[r][c] == player_idx:
            rightdown = rightdown + 1
            r = r + 1
            c = c + 1
        if leftup + rightdown + 1 >= 4: # more than four in a lu-rd diagonal
            # player win
            log.debug("Player %d win!" % player_idx)
            return True

        # check right-top to left-down diagonal
        rightup = leftdown = 0
        r = row - 1
        c = column + 1
        while r >= 0 and c < CHESSBOARD_COL and \
              self.matrix[r][c] == player_idx:
            rightup = rightup + 1
            r = r - 1
            c = c + 1
        r = row + 1
        c = column - 1
        while r < CHESSBOARD_ROW and c >= 0 and \
              self.matrix[r][c] == player_idx:
            leftdown = leftdown + 1
            r = r + 1
            c = c - 1
        if rightup + leftdown + 1 >= 4: # more than four in a ru-ld diagonal
            # player win
            log.debug("Player %d win!" % player_idx)
            return True

        log.debug("No one wins.")
        return False



########################################################################
class Server:
    """Server class. Focus on logical functions like create game,
    carry on game."""

    #----------------------------------------------------------------------
    def __init__(self, ip, port):
        """Constructor"""
        self.ip = ip
        self.port = port
        self.users = {}
        self.games = []
        self.waiting_queue = []
        self.running = True

        self.listener = ServerListener(ip, port, self)
        self.admin_cmd = AdminCmd(self)

    #----------------------------------------------------------------------
    def user_login(self, user_id, avatar_idx, handler):
        """"""
        user = User(user_id, avatar_idx, handler)
        self.users[user_id] = user

    #----------------------------------------------------------------------
    def user_logout(self, user_id):
        """"""
        if user_id in self.users:
            user = self.users[user_id]
            del self.users[user_id]
            if user.game: # if user is in a game, then close the game
                if user_id == user.game.user1.user_id:
                    opponent_user = user.game.user2
                elif user_id == user.game.user2.user_id:
                    opponent_user = user.game.user1
                else:
                    return
                # notify the other user the game has been terminated due to
                # player quit.
                opponent_user.handler.terminate_game('USER_LOGOUT')
                opponent_user.game = None
                # close the game
                self.games.remove(user.game)

    #----------------------------------------------------------------------
    def user_ready(self, user_id):
        """"""
        if user_id not in self.waiting_queue:
            self.waiting_queue.append(user_id)
            while len(self.waiting_queue) >= 2:
                # pair users and start game
                user1 = self.users[self.waiting_queue.pop(0)]
                user2 = self.users[self.waiting_queue.pop(0)]
                self.create_game(user1, user2)

    #----------------------------------------------------------------------
    def create_game(self, user1, user2):
        """"""
        # user1 move first
        user1.handler.start_game(1)
        user2.handler.start_game(0)
        game = Game(user1, user2)
        self.games.append(game)
        user1.game = game
        user2.game = game

    #----------------------------------------------------------------------
    def put_chess(self, user_id, row, column):
        """Put a chess, check win/draw."""
        user = self.users[user_id]
        game = user.game

        if game.user1.user_id == user_id:
            player_idx = 1
            opponent_user = game.user2
        elif game.user2.user_id == user_id:
            player_idx = 2
            opponent_user = game.user1
        else:
            return

        if game.check_pos(row, column):
            game.matrix[row][column] = player_idx
            game.steps.append((row, column))
            if game.check_win_after_put_chess(player_idx, row, column):
                if player_idx == 1: game.status = P1WIN
                elif player_idx == 2: game.status = P2WIN
            elif len(game.steps) == 42:
                game.status = DRAW
            else:
                if player_idx == 1: game.status = P2ROUND
                elif player_idx == 2: game.status = P1ROUND

            user.handler.put_chess_response(0, game.status)
            opponent_user.handler.put_chess_notification(row, column, game.status)
        else:
            user.handler.put_chess_response(1, game.status)

    #----------------------------------------------------------------------
    def start(self):
        """"""
        print "Server started. IP: %s Port: %d" % (self.ip, self.port)
        print "Type 'help' to list all commands."
        thread.start_new_thread(self.admin_cmd.run, ())

        while self.running:
            asyncore.loop(timeout=0.01,count=1)
            time.sleep(0.01)



if __name__ == '__main__':
    server = Server('0.0.0.0', 38324)
    server.start()
    print("Server exit.")